package org.example.cli.services

import org.example.auth.UserService
import org.example.cli.handlers.*
import org.example.service.*
import org.example.storage.StorageService

class CommandService {

    internal val instrumentService = InstrumentService()
    internal val calibrationService = CalibrationService(instrumentService)
    internal val maintenanceService = MaintenanceService(instrumentService)
    internal val userService = UserService()

    private val storageService = StorageService(
        instrumentService,
        calibrationService,
        maintenanceService
    )

    fun loadStartupData(path: String) = storageService.load(path)

    private val commands: Map<String, BaseHandler> = mapOf(
        "inst_add"    to InstAddHandler(),
        "inst_list"   to InstListHandler(),
        "inst_show"   to InstShowHandler(calibrationService),
        "inst_update" to InstUpdateHandler(),
        "inst_due"    to InstDueHandler(calibrationService),
        "cal_add"     to CalAddHandler(calibrationService),
        "cal_list"    to CalListHandler(calibrationService),
        "cal_show"    to CalShowHandler(calibrationService),
        "maint_add"   to MaintAddHandler(
            maintenanceService,
            userService
        ),
        "maint_list"  to MaintListHandler(maintenanceService),
        "save"        to SaveHandler(storageService),
        "load"        to LoadHandler(storageService),
        "help"        to HelpHandler(),
        "exit"        to ExitHandler()
    )

    fun execute(input: List<String>): Boolean {
        if (input.isEmpty()) return true
        val cmd = input[0]
        val handler = commands[cmd]
        return if (handler != null) {
            try { handler.handle(input.drop(1), instrumentService, commands.values) }
            catch (e: Exception) { ErrorHandler.handle(e); true }
        } else {
            println("Error: command not found: $cmd"); true
        }
    }
}
