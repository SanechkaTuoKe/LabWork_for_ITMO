package org.example.ui.instruments

import androidx.compose.runtime.mutableStateOf
import kotlinx.coroutines.*
import org.example.auth.UserService
import org.example.domain.*
import org.example.service.*
import org.example.storage.StorageService
import java.time.Instant

class InstrumentController(
    val instrumentService: InstrumentService,
    val calibrationService: CalibrationService,
    val maintenanceService: MaintenanceService,
    val storageService: StorageService
) {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    var instruments = mutableStateOf<List<Instrument>>(emptyList())
    var selected = mutableStateOf<Instrument?>(null)
    var isLoading = mutableStateOf(false)
    var error = mutableStateOf<String?>(null)
    var status = mutableStateOf("Ready")
    var calibrationUpdateCounter = mutableStateOf(0)
    var maintenanceUpdateCounter = mutableStateOf(0)

    init {
        refresh()
    }

    fun refresh() {
        scope.launch {
            isLoading.value = true
            try {
                val list = instrumentService.getAll()
                instruments.value = list
                status.value = "Loaded " + list.size
            } catch (e: Exception) {
                error.value = e.message
            }
            isLoading.value = false
        }
    }

    fun select(inst: Instrument) {
        selected.value = inst
    }

    fun add(name: String, type: InstrumentType, location: String, inventory: String?) {
        scope.launch {
            try {
                instrumentService.add(name, type, inventory, location)
                refresh()
                status.value = "Added"
            } catch (e: Exception) {
                error.value = e.message
            }
        }
    }

    fun edit(id: Long, name: String, location: String, inventory: String?) {
        scope.launch {
            try {
                instrumentService.update(id, name, location, inventory)
                refresh()
                status.value = "Updated"
            } catch (e: Exception) {
                error.value = e.message
            }
        }
    }

    fun delete(id: Long) {
        scope.launch {
            try {
                instrumentService.delete(id)
                selected.value = null
                refresh()
                status.value = "Deleted"
            } catch (e: Exception) {
                error.value = e.message
            }
        }
    }

    fun addCalibration(
        instrumentId: Long,
        type: String,
        result: String,
        comment: String?,
        date: Instant
    ) {
        scope.launch {
            try {
                calibrationService.add(
                    instrumentId,
                    type,
                    result,
                    comment,
                    "SYSTEM",
                    date
                )
                calibrationUpdateCounter.value = calibrationUpdateCounter.value + 1
                status.value = "Calibration added"
            } catch (e: Exception) {
                error.value = e.message
            }
        }
    }

    fun addMaintenance(
        instrumentId: Long,
        type: MaintenanceType,
        details: String,
        date: Instant
    ) {
        scope.launch {
            try {
                maintenanceService.add(
                    instrumentId,
                    type,
                    details,
                    "SYSTEM",
                    date
                )
                maintenanceUpdateCounter.value = maintenanceUpdateCounter.value + 1
                status.value = "Maintenance added"
            } catch (e: Exception) {
                error.value = e.message
            }
        }
    }

    fun save(path: String) {
        scope.launch {
            try {
                storageService.save(path)
                status.value = "Saved"
            } catch (e: Exception) {
                error.value = e.message
            }
        }
    }

    fun load(path: String) {
        scope.launch {
            try {
                storageService.load(path)
                refresh()
                status.value = "Loaded"
            } catch (e: Exception) {
                error.value = e.message
            }
        }
    }

    fun clearError() {
        error.value = null
    }

    fun clearStatus() {
        status.value = "Ready"
    }
}